#ifndef __TIMER_H
#define __TIMER_H
#include "sys.h"
#include "core.h"


extern Bool DIS_FLAG;

void TIM3_Int_Init(u16 arr,u16 psc) ;

#endif
